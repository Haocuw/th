    region_list = [
        'wor', # World
        'eu',  # Europe
        'us',  # USA
        'jp',  # Japan
        'ss',  # ScreenScraper
        'ame', # American continent
        'asi', # Asia
        'au',  # Australia
        'bg',  # Bulgaria
        'br',  # Brazil
        'ca',  # Canada
        'cl',  # Chile
        'cn',  # China
        'cus', # Custom
        'cz',  # Czech republic
        'de',  # Germany
        'dk',  # Denmark
        'fi',  # Finland
        'fr',  # France
        'gr',  # Greece
        'hu',  # Hungary
        'il',  # Israel
        'it',  # Italy
        'kr',  # Korea
        'kw',  # Kuwait
        'mor', # Middle East
        'nl',  # Netherlands
        'no',  # Norway
        'nz',  # New Zealand
        'oce', # Oceania
        'pe',  # Peru
        'pl',  # Poland
        'pt',  # Portugal
        'ru',  # Russia
        'se',  # Sweden
        'sk',  # Slovakia
        'sp',  # Spain
        'tr',  # Turkey
        'tw',  # Taiwan
        'uk',  # United Kingdom
    ]